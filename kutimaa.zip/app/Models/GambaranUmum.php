<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GambaranUmum extends Model
{
    protected $table = 'gambaran_umum';
    protected $fillable = ['isi_gambaran_umum'];
}
