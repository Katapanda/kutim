<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DasarHukum extends Model
{
     protected $table = 'dasar_hukums';
    protected $fillable = ['isi_dasar_hukum'];
}
