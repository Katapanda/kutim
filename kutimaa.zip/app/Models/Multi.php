<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Multi extends Model
{
    protected $table = 'multi';
    protected $fillable = ['gambar'];
}
