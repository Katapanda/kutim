<?php echo $__env->make('includes.function', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection('title'); ?>
	Bidang
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
	<!-- Banner area -->
    <section class="banner_area" data-stellar-background-ratio="0.5">
        <h2><?php echo e($bidang_detail->judul); ?></h2>
        <ol class="breadcrumb">
            <li><a href="">Informasi</a></li>
            <li><a href="" class="active"><?php echo e($bidang_detail->judul); ?></a></li>
        </ol>
    </section>
    <!-- End Banner area -->

    <!-- Dasar Hukum -->
    <section class="building_construction_area">
        <div class="container">
            <div class="row building_construction_row">
                <div class="col-sm-8 constructing_laft">
                    <h2><?php echo e($bidang_detail->judul); ?></h2>
                    <p>
                        <?php echo $bidang_detail->isi_bidang; ?>

                    </p>
                </div>
                
                <?php echo $__env->make('includes.sidebar_menu_profil', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            </div>
        </div>
    </section>
    <!-- End Dasar Hukum -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>