<!-- Top Bar -->

<!-- End Top Bar -->

<!-- Logo Area -->
<section class="logo-area" style="padding-bottom: 10px">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="logo">
                    <a href=""><img src="<?php echo e(asset('assets_frontend/images/logo.png')); ?>" alt="" class="img-fluid"></a>
                </div>
            </div>
            <div class="col-md-6">
                <div class="searchbar text-right">
                    <form action="#">
                        <input placeholder="Pencarian..." type="text" required="">
                        <button type="submit"><i class="fa fa-search"></i></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End Logo Area -->