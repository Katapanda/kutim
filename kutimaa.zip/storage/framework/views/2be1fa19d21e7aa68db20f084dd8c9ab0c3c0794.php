<div class="md-input-wrapper">
    <input type="text" class="md-form-control md-static" name="judul_berita" required placeholder="Judul" value="<?php echo e($isi['judul_berita']); ?>">
    <label>Judul Berita</label>
    <span class="help-block with-errors"></span>
  </div>
  <div class="md-input-wrapper">
    <input type="text" class="md-form-control md-static" name="sumber" required placeholder="Sumber" value="<?php echo e($isi['sumber']); ?>">
    <label>Sumber</label>
    <span class="help-block with-errors"></span>
  </div>
  <div class="md-input-wrapper">
    <input type="text" class="md-form-control md-static" name="tanggal_publish" id="datepicker" required placeholder="Tanggal" value="<?php echo e($isi['tanggal_publish']); ?>">
    <label>Tanggal Publish</label>
    <span class="help-block with-errors"></span>
  </div>
  <div class="md-input-wrapper">
    <input type="file" class="md-form-control md-static" name="foto_berita">
    <label>Foto</label>
    <span class="help-block with-errors"></span>
  </div>
  <div class="md-input-wrapper">
    <textarea name="isi_berita"><?php echo e($isi['isi_berita']); ?></textarea>
    <span class="help-block with-errors"></span>
  </div>

    <script src="<?php echo e(asset('assets/plugins/tinymce/tinymce.min.js')); ?>"></script>
    <script type="text/javascript">
        tinymce.init({
          selector: 'textarea',
          height: 500,
          menubar: false,
          plugins: [
            'advlist autolink lists link image charmap print preview anchor textcolor',
            'searchreplace visualblocks code fullscreen',
            'insertdatetime media table contextmenu paste code help wordcount'
          ],
          toolbar: 'insert | undo redo |  formatselect | bold italic backcolor  | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | removeformat | help',
          content_css: [
            '//fonts.googleapis.com/css?family=Lato:300,300i,400,400i',
            '//www.tinymce.com/css/codepen.min.css']
        });
        $("#datepicker").bootstrapMaterialDatePicker({ weekStart : 0, time: false, format : 'YYYY/MM/DD' });
    </script>