<div class="col-sm-4 constructing_right">
    <h2>Menu Profil</h2>
    <ul class="painting">
        <li><a href="<?php echo e(route('dasar-hukum')); ?>"><i class="fa fa-wrench" aria-hidden="true"></i>Dasar Hukum</a></li>
        <li><a href="<?php echo e(route('struktur-organisasi')); ?>"><i class="fa fa-cogs" aria-hidden="true"></i>Struktur Organisasi</a></li>
        <li><a href="<?php echo e(route('tugas-pokok-dan-fungsi')); ?>"><i class="fa fa-heart" aria-hidden="true"></i>Tugas Pokok dan Fungsi</a></li>
        <li><a href="<?php echo e(route('visi-misi')); ?>"><i class="fa fa-paint-brush" aria-hidden="true"></i>Visi dan Misi</a></li>
    </ul>
</div>