<!-- Bootstrap CSS -->
<link href="<?php echo e(asset('assets_frontend/css/bootstrap.min.css')); ?>" rel="stylesheet">
<!-- Animate CSS -->
<link href="<?php echo e(asset('assets_frontend/vendors/animate/animate.css')); ?>" rel="stylesheet">
<!-- Icon CSS-->
<link rel="stylesheet" href="<?php echo e(asset('assets_frontend/vendors/font-awesome/css/font-awesome.min.css')); ?>">
<!-- Camera Slider -->
<link rel="stylesheet" href="<?php echo e(asset('assets_frontend/vendors/camera-slider/camera.css')); ?>">
<!-- Owlcarousel CSS-->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets_frontend/vendors/owl_carousel/owl.carousel.css')); ?>" media="all">

<!--Theme Styles CSS-->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/plugins/orgchart/orgchart.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets_frontend/css/style.css')); ?>" media="all" />