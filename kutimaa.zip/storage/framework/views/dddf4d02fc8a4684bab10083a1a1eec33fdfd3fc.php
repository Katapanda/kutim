<?php echo $__env->make('includes.function', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection('title'); ?>
	Foto
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
	<!-- Banner area -->
    <section class="banner_area" data-stellar-background-ratio="0.5">
        <h2>Foto</h2>
        <ol class="breadcrumb">
            <li><a href="">Galeri</a></li>
            <li><a href="" class="active">Foto</a></li>
        </ol>
    </section>
    <!-- End Banner area -->

    <!-- Foto -->
    <section class="featured_works row" data-stellar-background-ratio="0.3">
        <div class="featured_gallery">
            <?php $__currentLoopData = $foto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ft): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                <div class="col-md-3 col-sm-4 col-xs-6 gallery_iner p0">
                    <img src="<?php echo e(asset($ft->foto)); ?>" alt="" width="100%" height="200px">
                    <div class="gallery_hover">
                        <h4></h4>
                        <a href="#">Perbesar</a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
    <!-- End Foto -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>