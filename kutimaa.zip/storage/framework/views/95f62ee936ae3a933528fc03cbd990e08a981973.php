<?php $__env->startSection('title'); ?>
    Detail Album
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="main-header">
            <h4>Detail Album</h4>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-header-text">Detail Album</h5>

                </div>
                <div class="card-block" style="float: center;">
                      <div class="row" id="galery">
                        <?php $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <div class="col-md-2">
                            <a href="<?php echo e(url($foto->foto)); ?>" target="_blank">
                              <img src="<?php echo e(url($foto->foto)); ?>" class="img-thumbnail">
                            </a>
                          </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </div>
                      <div class="row">
                        <div class="col-md-12">
                          <form action="<?php echo e(url('admin/api/imgalbum')); ?>" class="dropzone" id="addImages">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="id_album" value="<?php echo e($data['id']); ?>">
                          </form>
                          <label style="color: red">Silahkan Drag foto Atau Klik Dan Masukan Banyak Foto, dngan Maksimal Size 2 MB/Foto</label>
                        </div>
                      </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    
    <script src="<?php echo e(asset('assets/plugins/dropzone/dropzone.min.js')); ?>"></script>
    <script type="text/javascript">
        $("#datepicker").bootstrapMaterialDatePicker({ weekStart : 0, time: false, format : 'YYYY/MM/DD' });
        $('#time').bootstrapMaterialDatePicker({ date: false, format : 'HH:mm'});
    </script>
    <script type="text/javascript">
      Dropzone.options.addImages = {
        maxFilesize: 2,
        acceptedFiles: 'image/*',
        success: function(file, respone) {
          if (file.status == 'success') {
            handleDropzoneFileUpload.handleSuccess(respone);
          } else {
            handleDropzoneFileUpload.handleError(respone);
          }
        }
      };

      var handleDropzoneFileUpload = {
        handleError: function(respone) {
          
        }, 
        handleSuccess: function(respone) {
          var imageList = $('#galery');
          var imageSrc = "<?php echo e(url('/')); ?>" + respone.foto;
          $(imageList).append('<div class="col-md-2">'+
                            '<a href="'+imageSrc+'" target="_blank">'+
                              '<img src="'+imageSrc+'" class="img-thumbnail">'+
                            '</a>'+
                          '</div>');
        }
      };
    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>