<!doctype html>
<html class="no-js" lang="zxx">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title>Kutim | <?php echo $__env->yieldContent('title'); ?></title>

        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Favicon -->
        <link rel="shortcut icon" href="<?php echo e(asset('assets_frontend/images/favicon.png')); ?>" type="image/x-icon">
        <link rel="icon" href="<?php echo e(asset('assets_frontend/images/favicon.png')); ?>" type="image/x-icon">

        
        <?php echo $__env->make('includes.style', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </head>

    <body>

        <!-- Preloader -->
        <div class="preloader"></div>
        <!-- End Pre-Loader -->

        
        <?php echo $__env->make('includes.topbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        
        <?php echo $__env->make('includes.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        
        <?php echo $__env->yieldContent('content'); ?>

        
        <?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        
        <?php echo $__env->make('includes.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </body>
</html>      
