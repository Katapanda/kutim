<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900" rel="stylesheet">

<!-- Bootstrap -->
<link rel="stylesheet" href="<?php echo e(asset('assets_frontend/css/assets/bootstrap.min.css')); ?>">

<!-- Fontawesome Icon -->
<link rel="stylesheet" href="<?php echo e(asset('assets_frontend/css/assets/font-awesome.min.css')); ?>">

<!-- Animate CSS -->
<link rel="stylesheet" href="<?php echo e(asset('assets_frontend/css/assets/animate.css')); ?>">

<!-- Mean Menu -->
<link rel="stylesheet" href="<?php echo e(asset('assets_frontend/css/assets/meanmenu.min.css')); ?>">

<!-- Owl Carousel -->
<link rel="stylesheet" href="<?php echo e(asset('assets_frontend/css/assets/owl.carousel.min.css')); ?>">

<!-- Magnific Popup -->
<link rel="stylesheet" href="<?php echo e(asset('assets_frontend/css/assets/magnific-popup.css')); ?>">

<!-- Custom Style -->
<link rel="stylesheet" href="<?php echo e(asset('assets_frontend/css/assets/normalize.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets_frontend/css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets_frontend/css/assets/responsive.css')); ?>">