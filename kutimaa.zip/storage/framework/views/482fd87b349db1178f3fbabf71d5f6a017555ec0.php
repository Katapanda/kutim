<?php echo $__env->make('includes.function', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection('title'); ?>
	Struktur Organisasi
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/plugins/orgchart/orgchart.css')); ?>">
	<!-- Banner area -->
    <section class="banner_area" data-stellar-background-ratio="0.5">
        <h2>Struktur Organisasi</h2>
        <ol class="breadcrumb">
            <li><a href="">Informasi</a></li>
            <li><a href="" class="active">Struktur Organisasi</a></li>
        </ol>
    </section>
    <!-- End Banner area -->

    <!-- Struktur Organisasi -->
    <section class="building_construction_area">
        <div class="container">
            <div class="row building_construction_row">
                <div class="col-sm-8 constructing_laft">
                    <h2>Struktur Organisasi</h2>
                    <div class="row" style="overflow-y: auto;overflow-x: scroll;">
                        <ul id="tree-data" style="display:none;">
                            <li id="root" >
                                <?php if($kepala_dinas): ?>
                                <a href="#" onclick="detail('Kepala Dinas')" style="color: #fff; font-size: 14px">
                                    <img src="<?php echo e(url($kepala_dinas['foto'])); ?>" style="width: 120px; height: 120px; margin-right: 10px">
                                    <p style="color: #fff; font-size: 14px">Kepala Dinas<br><?php echo e($kepala_dinas['nama']); ?> </p>
                                </a>
                                <?php else: ?> 
                                <a href="#" onclick="detail('Kepala Dinas')" style="color: #fff; font-size: 14px">
                                    <img src="<?php echo e(asset('images/close.png')); ?>" style="width: 120px; height: 120px; margin-right: 10px">
                                    <p style="color: #fff; font-size: 14px">Kepala Dinas<br></p>
                                </a>
                                <?php endif; ?>
                                <ul>
                                    <li id="node1">
                                        <?php if($kjf): ?>
                                        <a href="#" onclick="detail('Kelmpok Jabatan Fungsional')">
                                            <img src="<?php echo e(url($kjf['foto'])); ?>" style="width: 120px; height: 120px; margin-right: 10px">
                                            <p style="color: #fff; font-size: 14px">Kelmpok Jabatan Fungsional <br> <?php echo e($kjf['nama']); ?>. </p>
                                        </a>
                                        <?php else: ?> 
                                        <a href="#" onclick="detail('Kelmpok Jabatan Fungsional')">
                                            <img src="<?php echo e(asset('images/close.png')); ?>" style="width: 120px; height: 120px; margin-right: 10px">
                                            <p style="color: #fff; font-size: 14px">Kelmpok Jabatan Fungsional <br>. </p>
                                        </a>
                                        <?php endif; ?>
                                    </li>

                                    <li id="node2">
                                        <?php if($kbp): ?>
                                        <a href="#" onclick="detail('Kepala Bidang Perumahan')">
                                            <img src="<?php echo e(url($kbp['foto'])); ?>" style="width: 120px; height: 120px; margin-right: 10px">
                                            <p style="color: #fff; font-size: 14px">Kepala Bidang Perumahan <br> <?php echo e($kbp['nama']); ?></p>
                                        </a>
                                        <?php else: ?>
                                        <a href="#" onclick="detail('Kepala Bidang Perumahan')">
                                            <img src="<?php echo e(asset('images/close.png')); ?>" style="width: 120px; height: 120px; margin-right: 10px">
                                            <p style="color: #fff; font-size: 14px">Kepala Bidang Perumahan <br></p>
                                        </a>
                                        <?php endif; ?>
                                        <ul>
                                            <li id="node6">
                                                <?php if($kpme): ?>
                                                <a href="#" style="color: #fff; font-size: 14px" onclick="detail('Kasubbid Perencanaan, Monitoring & Evaluasi')">
                                                <img src="<?php echo e(url($kpme['foto'])); ?>" style="width: 120px; height: 120px; margin-right: 10px">
                                                    Kasubbid Perencanaan, Monitoring & Evaluasi <br> <?php echo e($kpme['nama']); ?>

                                                </a>
                                                <?php else: ?>
                                                <a href="#" style="color: #fff; font-size: 14px"  onclick="detail('Kasubbid Perencanaan, Monitoring & Evaluasi')">
                                                <img src="<?php echo e(asset('images/close.png')); ?>" style="width: 120px; height: 120px; margin-right: 10px">
                                                    Kasubbid Perencanaan, Monitoring & Evaluasi <br>
                                                </a>
                                                <?php endif; ?>
                                            </li>
                                            <li id="node6">
                                                <?php if($kpn): ?>
                                                <a href="#" style="color: #fff; font-size: 14px" onclick="detail('Kasubbid Penyediaan')">
                                                <img src="<?php echo e(url($kpn['foto'])); ?>" style="width: 120px; height: 120px; margin-right: 10px">
                                                    Kasubbid Penyediaan <br> <?php echo e($kpn['nama']); ?>

                                                </a>
                                                <?php else: ?>
                                                <a href="#" style="color: #fff; font-size: 14px" onclick="detail('Kasubbid Penyediaan')">
                                                <img src="<?php echo e(asset('images/close.png')); ?>" style="width: 120px; height: 120px; margin-right: 10px">
                                                    Kasubbid Penyediaan <br>
                                                </a>
                                                <?php endif; ?>
                                            </li>
                                            <li id="node6">
                                                <?php if($kpm): ?>
                                                <a href="#" style="color: #fff; font-size: 14px" onclick="detail('Kasubbid Pembiayaan')">
                                                <img src="<?php echo e(url($kpm['foto'])); ?>" style="width: 120px; height: 120px; margin-right: 10px">
                                                    Kasubbid Pembiayaan <br> <?php echo e($kpm['nama']); ?>

                                                </a>
                                                <?php else: ?>
                                                <a href="#" style="color: #fff; font-size: 14px" onclick="detail('Kasubbid Pembiayaan')">
                                                <img src="<?php echo e(asset('images/close.png')); ?>" style="width: 120px; height: 120px; margin-right: 10px">
                                                    Kasubbid Pembiayaan <br>
                                                </a>
                                                <?php endif; ?>
                                            </li>
                                        </ul>
                                    </li>
                                    <li id="node5">
                                        <?php if($usp): ?>
                                        <a href="#" onclick="detail('UPT Sangata Utara')">
                                            <img src="<?php echo e(url($usp['foto'])); ?>" style="width: 120px; height: 120px;  margin-right: 10px">
                                            <p style="color: #fff; font-size: 14px">UPT Sangata Utara <br> <?php echo e($usp['nama']); ?></p>
                                        </a>
                                        <?php else: ?>
                                        <a href="#" onclick="detail('UPT Sangata Utara')">
                                            <img src="<?php echo e(asset('images/close.png')); ?>" style="width: 120px; height: 120px;  margin-right: 10px">
                                            <p style="color: #fff; font-size: 14px">UPT Sangata Utara <br></p>
                                        </a>
                                        <?php endif; ?>
                                    </li>
                                    <li id="node5">
                                        <?php if($uss): ?>
                                        <a href="#" onclick="detail('UPT Sangata Selatan')">
                                            <img src="<?php echo e(url($uss['foto'])); ?>" style="width: 120px; height: 120px;  margin-right: 10px">
                                            <p style="color: #fff; font-size: 14px">UPT Sangata Selatan <br> <?php echo e($uss['nama']); ?></p>
                                        </a>
                                        <?php else: ?>
                                        <a href="#" onclick="detail('UPT Sangata Selatan')">
                                            <img src="<?php echo e(asset('images/close.png')); ?>" style="width: 120px; height: 120px;  margin-right: 10px">
                                            <p style="color: #fff; font-size: 14px">UPT Sangata Selatan <br></p>
                                        </a>
                                        <?php endif; ?>
                                    </li>
                                    <li id="node5">
                                        <?php if($kbkp): ?>
                                        <a href="#" onclick="detail('Kepla Bidang Kawasan Pemukiman')">
                                            <img src="<?php echo e(url($kbkp['foto'])); ?>" style="width: 120px; height: 120px;  margin-right: 10px">
                                            <p style="color: #fff; font-size: 14px">Kepla Bidang Kawasan Pemukiman <br> <?php echo e($kbkp['nama']); ?></p>
                                        </a>
                                        <?php else: ?>
                                        <a href="#" onclick="detail('Kepla Bidang Kawasan Pemukiman')">
                                            <img src="<?php echo e(asset('images/close.png')); ?>" style="width: 120px; height: 120px;  margin-right: 10px">
                                            <p style="color: #fff; font-size: 14px">Kepla Bidang Kawasan Pemukiman <br></p>
                                        </a>
                                        <?php endif; ?>
                                       <ul>
                                            <li id="node6">
                                                <?php if($kpdp): ?>
                                                <a href="#" style="color: #fff; font-size: 14px" onclick="detail('Kasubbid Pendataan Dan Perencanaan')"> 
                                                <img src="<?php echo e(url($kpdp['foto'])); ?>" style="width: 120px; height: 120px; margin-right: 10px">
                                                Kasubbid Pendataan Dan Perencanaan <br> <?php echo e($kpdp['nama']); ?>

                                                </a>
                                                <?php else: ?>
                                                <a href="#" style="color: #fff; font-size: 14px" onclick="detail('Kasubbid Pendataan Dan Perencanaan')">
                                                    <img src="<?php echo e(asset('images/close.png')); ?>" style="width: 120px; height: 120px; margin-right: 10px">
                                                     Kasubbid Pendataan Dan Perencanaan <br>
                                                </a>
                                                <?php endif; ?>
                                            </li>
                                            <li id="node6">
                                                <?php if($kpdpk): ?>
                                                <a href="#" style="color: #fff; font-size: 14px" onclick="detail('Kasubbid Pencegahan Dan Peningkatan Kualitas')">
                                                <img src="<?php echo e(url($kpdpk['foto'])); ?>" style="width: 120px; height: 120px; margin-right: 10px">
                                                    Kasubbid Pencegahan Dan Peningkatan Kualitas <br> <?php echo e($kpdpk['nama']); ?>

                                                </a>
                                                <?php else: ?>
                                                <a href="#" style="color: #fff; font-size: 14px" onclick="detail('Kasubbid Pencegahan Dan Peningkatan Kualitas')">
                                                <img src="<?php echo e(asset('images/close.png')); ?>" style="width: 120px; height: 120px; margin-right: 10px">
                                                    Kasubbid Pencegahan Dan Peningkatan Kualitas <br>
                                                </a>
                                                <?php endif; ?>
                                            </li>
                                            <li id="node6">
                                                <?php if($kmdp): ?>
                                                <a href="#" style="color: #fff; font-size: 14px" onclick="detail('Kasubbid Manfaat Dan Pengendalian')">
                                                <img src="<?php echo e(url($kmdp['foto'])); ?>" style="width: 120px; height: 120px; margin-right: 10px">
                                                    Kasubbid Manfaat Dan Pengendalian <br> <?php echo e($kmdp['nama']); ?>

                                                </a>
                                                <?php else: ?>
                                                <a href="#" style="color: #fff; font-size: 14px" onclick="detail('Kasubbid Manfaat Dan Pengendalian')">
                                                <img src="<?php echo e(asset('images/close.png')); ?>" style="width: 120px; height: 120px; margin-right: 10px">
                                                    Kasubbid Manfaat Dan Pengendalian <br>
                                                </a>
                                                <?php endif; ?>
                                            </li>
                                        </ul>
                                    </li>
                                    <li id="node5">
                                        <?php if($sekertaris): ?>
                                        <a href="#" onclick="detail('Sekertaris')">
                                            <img src="<?php echo e(url($sekertaris['foto'])); ?>" style="width: 120px; height: 120px;  margin-right: 10px">
                                            <p style="color: #fff; font-size: 14px">Sekertaris <br> <?php echo e($sekertaris['nama']); ?></p>
                                        </a>
                                        <?php else: ?>
                                        <a href="#" onclick="detail('Sekertaris')">
                                            <img src="<?php echo e(asset('images/close.png')); ?>" style="width: 120px; height: 120px;  margin-right: 10px">
                                            <p style="color: #fff; font-size: 14px">Sekertaris <br></p>
                                        </a>
                                        <?php endif; ?>
                                       <ul>
                                            <li id="node6">
                                                <?php if($kppdk): ?>
                                                <a href="#" style="color: #fff; font-size: 14px" onclick="detail('Kasubbag Perencanaan Program Dan Keuangan')">
                                                <img src="<?php echo e(url($kppdk['foto'])); ?>" style="width: 120px; height: 120px; margin-right: 10px">
                                                    Kasubbag Perencanaan Program Dan Keuangan <br> <?php echo e($kppdk['nama']); ?>

                                                </a>
                                                <?php else: ?>
                                                <a href="#" style="color: #fff; font-size: 14px" onclick="detail('Kasubbag Perencanaan Program Dan Keuangan')">
                                                <img src="<?php echo e(asset('images/close.png')); ?>" style="width: 120px; height: 120px; margin-right: 10px">
                                                    Kasubbag Perencanaan Program Dan Keuangan <br>
                                                </a>
                                                <?php endif; ?>
                                            </li>
                                            <li id="node6">
                                                <?php if($kudk): ?>
                                                <a href="#" style="color: #fff; font-size: 14px" onclick="detail('Kasubbag Umum Dan Kepegawaian')">
                                                <img src="<?php echo e(url($kudk['foto'])); ?>" style="width: 120px; height: 120px; margin-right: 10px">
                                                    Kasubbag Umum Dan Kepegawaian <br> <?php echo e($kudk['nama']); ?>

                                                </a>
                                                <?php else: ?>
                                                <a href="#" style="color: #fff; font-size: 14px" onclick="detail('Kasubbag Umum Dan Kepegawaian')">
                                                <img src="<?php echo e(asset('images/close.png')); ?>" style="width: 120px; height: 120px; margin-right: 10px">
                                                    Kasubbag Umum Dan Kepegawaian <br>
                                                </a>
                                                <?php endif; ?>
                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                                
                            </li>
                        </ul>
                        <div id="tree-view"></div> 
                    </div>
                </div>
                
                <?php echo $__env->make('includes.sidebar_menu_profil', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            </div>
        </div>
    </section>
    <!-- End Struktur Organisasi -->
<div class="modal fade" id="detail" tabindex="-1" role="dialog" style="display: none; margin-top: 10%">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="defaultModalLabel">Detail Jabatan</h4>
            </div>
            <div class="modal-body">
                <input type="hidden" id="id_hps" name="id">
                <div class="row">
                    <div class="col-md-12">
                        <table class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <td>Nama</td>
                                    <td>Jabatan</td>
                                    <td>Email</td>
                                    <td>Bidang</td>
                                    <td>Sub Bidang</td>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td id="nama"></td>
                                    <td id="jabatan"></td>
                                    <td id="email"></td>
                                    <td id="bidang"></td>
                                    <td id="sub_bidang"></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div><br>
                <div class="row">
                    <div class="col-md-12">
                        <table class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Nip</th>
                                    <th>Nama</th>
                                </tr>
                            </thead>
                            <tbody id="list_anggota">
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>