<?php echo $__env->make('includes.function', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection('title'); ?>
	Beranda
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- Web Ticker -->
    <section class="top-news">
        <div class="container">
            <div class="news-content">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="ticker d-flex justify-content-between">
                            <div class="news-head">
                                <span>BERITA TERBARU<i class="fa fa-caret-right"></i></span>
                            </div>
                            <ul id="webTicker">

                                <?php $__currentLoopData = $breaking_news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breaking_new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <li><a href=""><i class="fa fa-dot-circle-o"></i><?php echo e($breaking_new->judul_berita); ?></a></li>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End Web Ticker -->

    <!-- Slider Area -->
    <section class="slider-area">
        <div class="container">
            <div class="row">
                    
                <div class="col-lg-8 col-md-12 padding-fix-r">
                    <div class="owl-carousel owl-slider">
                        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="slider-content">
                            
                            <img src="<?php echo e(asset($slider->foto_berita)); ?>" alt="" class="img-fluid" style="height: 470px" width="100%">
                            <div class="slider-layer" style="width: 100%;">
                                <p>
                                    <a href="" style="color: #ffffff; text-align: left;">
                                        
                                        <?php echo substr($slider->isi_berita, 0, 200) . '...'; ?>   
                                        
                                    </a>
                                </p>
                                <ul class="list-unstyled list-inline">
                                    <li class="list-inline-item"><?php echo substr($slider->judul_berita, 0, 20) . '...'; ?> </li>
                                    <li class="list-inline-item"><?php echo e(tanggal_indo($slider->tanggal_publish)); ?></li>
                                </ul>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
                <div class="col-lg-4 col-md-12 slider-fix">

                    <?php $__currentLoopData = $slider_sides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider_side): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php if(strlen($slider_side->isi_berita) > 100): ?>

                            <div class="slider-sidebar sidebar-o">
                                <img src="<?php echo e(asset($slider_side->foto_berita)); ?>" alt="" class="img-fluid" style="height: 230px" width="100%">
                                <div class="sidebar-layer">
                                    <p>
                                        <a href="">
                                            <?php echo substr($slider_side->isi_berita, 0, 100) . '...'; ?> 
                                        </a>
                                    </p>
                                    <ul class="list-unstyled list-inline">
                                        <li class="list-inline-item">
                                            <?php if(strlen($slider_side->judul_berita) > 10): ?>
                                            
                                                <?php echo substr($slider_side->judul_berita, 0, 10) . '...'; ?>   
                                            
                                            <?php else: ?>

                                               <?php echo $slider_side->judul_berita; ?>


                                            <?php endif; ?>
                                        </li>
                                        <li class="list-inline-item"><?php echo e(tanggal_indo($slider_side->tanggal_publish)); ?></li>
                                    </ul>
                                </div>
                            </div>
                                                
                        <?php else: ?>

                           <?php echo $slider_side->isi_berita; ?>


                        <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>
    </section>
    <!-- End Slider Area -->
    
    

    <!-- All News -->
    
    <!-- End All News -->

    <section class="oth-news">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="more-top">
                        <h4>ARTIKEL</h4>
                    </div>
                    <div class="more-content">
                        <div class="more-img">
                            <a href=""><img src="<?php echo e(asset('upload/foto_berita/diprotes-pembangunan-2-gedung-sekolah-dikerjakan-malam-malam.jpg')); ?>" alt="" class="img-responsive" width="260px" height="169px"></a>
                        </div>
                        <div class="img-content">
                            <h6><a href="">It is usually composed of several sentences that together develop one.</a></h6>
                            <ul class="list-unstyled list-inline">
                                <li class="list-inline-item">FAMILY</li>
                                <li class="list-inline-item">September 24, 2017</li>
                            </ul>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi debitis suscipit nesciunt nihil deleniti dolorum reiciendis aspernatur recusandae in, dolore quod pariatur......</p>
                        </div>
                    </div>
                    <div class="more-content">
                        <div class="more-img">
                            <a href=""><img src="<?php echo e(asset('upload/foto_berita/pemerintah-kutai-timur-fokus-bangun-infrastruktur-jalan.jpg')); ?>" alt="" class="img-responsive" width="260px" height="169px"></a>
                        </div>
                        <div class="img-content">
                            <h6><a href="">It is usually composed of several sentences that together develop one.</a></h6>
                            <ul class="list-unstyled list-inline">
                                <li class="list-inline-item">LIFESTYLE</li>
                                <li class="list-inline-item">September 24, 2017</li>
                            </ul>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi debitis suscipit nesciunt nihil deleniti dolorum reiciendis aspernatur recusandae in, dolore quod pariatur......</p>
                        </div>
                    </div>
                    <div class="more-content">
                        <div class="more-img">
                            <a href=""><img src="<?php echo e(asset('upload/foto_berita/jemaah-umrah-indonesia-kini-tak-bisa-transit-ke-banyak-negara.jpg')); ?>" alt="" class="img-responsive" width="260px" height="169px"></a>
                        </div>
                        <div class="img-content">
                            <h6><a href="">It is usually composed of several sentences that together develop one.</a></h6>
                            <ul class="list-unstyled list-inline">
                                <li class="list-inline-item">WORLD</li>
                                <li class="list-inline-item">September 24, 2017</li>
                            </ul>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi debitis suscipit nesciunt nihil deleniti dolorum reiciendis aspernatur recusandae in, dolore quod pariatur......</p>
                        </div>
                    </div>
                    <div class="more-content">
                        <div class="more-img">
                            <a href=""><img src="<?php echo e(asset('upload/foto_berita/kutai-timur-raih-lpse-terbaik-2014.jpg')); ?>" alt="" class="img-responsive" width="260px" height="169px"></a>
                        </div>
                        <div class="img-content">
                            <h6><a href="">It is usually composed of several sentences that together develop one.</a></h6>
                            <ul class="list-unstyled list-inline">
                                <li class="list-inline-item">TECHNOLOGY</li>
                                <li class="list-inline-item">September 24, 2017</li>
                            </ul>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi debitis suscipit nesciunt nihil deleniti dolorum reiciendis aspernatur recusandae in, dolore quod pariatur......</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-12">
                   <div class="more-top">
                        <h4>Kepala Dinas</h4>
                    </div>
                    <div class="add-widget">
                        <a href=""><img src="<?php echo e(asset('upload/foto_struktur_organisasi/10112378.JPG')); ?>" alt="" class="img-fluid" width="50%" height="300px"></a>
                    </div>

                </div>
            </div>
        </div>
    </section>

    <!-- Latest Videos -->
    <section class="videos">
        <div class="container">
            <div class="vodeo-c">
                <div class="row">
                    <div class="col-md-12">
                        <div class="video-top">
                            <h4>VIDEO KEGIATAN</h4>
                        </div>
                    </div>
                    <div class="col-lg-8 col-md-12">
                        <div class="video-content text-center">
                            <a href="https://www.youtube.com/watch?v=uXFUl0KcIkA" id="video-btn"><i class="fa fa-play"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-4  col-md-12">
                        <div class="video-list">
                            <div class="list-content">
                                <img src="<?php echo e(asset('assets_frontend/images/latest-4.jpg')); ?>" alt="" class="img-fluid">
                                <p><a href="">These sentences are selected from various online news.</a></p>
                            </div>
                            <div class="list-content">
                                <img src="<?php echo e(asset('assets_frontend/images/latest-5.jpg')); ?>" alt="" class="img-fluid">
                                <p><a href="">These sentences are selected from various online news.</a></p>
                            </div>
                            <div class="list-content">
                                <img src="<?php echo e(asset('assets_frontend/images/latest-7.jpg')); ?>" alt="" class="img-fluid">
                                <p><a href="">These sentences are selected from various online news.</a></p>
                            </div>
                            <div class="list-content">
                                <img src="<?php echo e(asset('assets_frontend/images/latest-6.jpg')); ?>" alt="" class="img-fluid">
                                <p><a href="">These sentences are selected from various online news.</a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End Latest Videos -->
    
    <!-- Other News -->
    
    <!-- End Other News -->



    <!-- Modal Sambutan-->
    <div class="modal fade" id="sambutan-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <img src="<?php echo e(asset('assets_frontend/images/logo.png')); ?>" class="img-responsive" alt="">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <?php $__currentLoopData = $sambutans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sambutan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $sambutan->isi_sambutan; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>