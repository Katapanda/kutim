<!-- Footer --> 
<footer class="footer_area">
    <div class="container">
        <div class="footer_row row">
            <div class="col-md-12 col-sm-12 footer_about text-center">
                <h2>Dinas Perumahan dan Kawasan Permukiman Kabupaten Kutai Timur</h2>
                <address>
                    <ul class="my_address">
                        <li><a href="#"><i class="fa fa-envelope" aria-hidden="true"></i>
                            <?php $__currentLoopData = $kontak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($kon->email); ?>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </a></li>
                        <li><a href="#"><i class="fa fa-phone" aria-hidden="true"></i>
                            <?php $__currentLoopData = $kontak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($kon->telepon); ?>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </a></li>
                        <li><a href="#"><i class="fa fa-map-marker" aria-hidden="true"></i>
                            <?php $__currentLoopData = $kontak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($kon->lokasi); ?>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </a></li>
                    </ul>
                </address>
            </div>
        </div>
    </div>
    <div class="copyright_area">
        Copyright 2018 - Dinas Perumahan dan Kawasan Permukiman Kabupaten Kutai Timur
    </div>
</footer>
<!-- End Footer --> 