<!-- Top Header_Area -->
<section class="top_header_area">
    <div class="container">
        <ul class="nav navbar-nav top_nav">
            <li><a href=""><i class="fa fa-phone"></i>
                <?php $__currentLoopData = $kontak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($kon->telepon); ?>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </a></li>
            <li><a href=""><i class="fa fa-envelope-o"></i><?php $__currentLoopData = $kontak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($kon->email); ?>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></a></li>
        </ul>
        <ul class="nav navbar-nav navbar-right social_nav">
            <li><a href=""><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
            <li><a href=""><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
            <li><a href=""><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
        </ul>
    </div>
</section>
<!-- End Top Header_Area -->