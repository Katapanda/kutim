<!-- =========================================
JavaScript Files
========================================== -->

<!-- jQuery JS -->
<script src="<?php echo e(asset('assets_frontend/js/assets/vendor/jquery-1.12.4.min.js')); ?>"></script>

<!-- Poppers Js -->
<script src="<?php echo e(asset('assets_frontend/js/assets/popper.js')); ?>"></script>

<!-- Bootstrap -->
<script src="<?php echo e(asset('assets_frontend/js/assets/bootstrap.min.js')); ?>"></script>
	
<!-- Sticky Js -->
<script src="<?php echo e(asset('assets_frontend/js/assets/jquery.sticky.js')); ?>"></script>

<!-- WOW JS -->
<script src="<?php echo e(asset('assets_frontend/js/assets/wow.min.js')); ?>"></script>

<!-- Smooth Scroll -->
<script src="<?php echo e(asset('assets_frontend/js/assets/smooth-scroll.js')); ?>"></script>

<!-- Mean Menu -->
<script src="<?php echo e(asset('assets_frontend/js/assets/jquery.meanmenu.min.js')); ?>"></script>

<!-- News Ticker -->
<script src="<?php echo e(asset('assets_frontend/js/assets/jquery.newsticker.min.js')); ?>"></script>

<!-- Owl Carousel -->
<script src="<?php echo e(asset('assets_frontend/js/assets/owl.carousel.min.js')); ?>"></script>

<!-- Magnific Popup -->
<script src="<?php echo e(asset('assets_frontend/js/assets/jquery.magnific-popup.min.js')); ?>"></script>

<!-- Syotimer -->
<script src="<?php echo e(asset('assets_frontend/js/assets/jquery.syotimer.min.js')); ?>"></script>

<!-- Custom JS -->
<script src="<?php echo e(asset('assets_frontend/js/plugins.js')); ?>"></script>
<script src="<?php echo e(asset('assets_frontend/js/custom.js')); ?>"></script>